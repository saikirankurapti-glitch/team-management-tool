---
name: TMP Engineering OS
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#c3c6d2'
  on-secondary: '#2c3039'
  secondary-container: '#454953'
  on-secondary-container: '#b5b8c3'
  tertiary: '#ffffff'
  on-tertiary: '#68000a'
  tertiary-container: '#ffdad7'
  on-tertiary-container: '#c22229'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#dfe2ee'
  secondary-fixed-dim: '#c3c6d2'
  on-secondary-fixed: '#181c24'
  on-secondary-fixed-variant: '#434750'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-sm: 0.75rem
  margin: 1.75rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-performance, developer-first engineering operating system. The interface transitions away from low-contrast, murky olive tints to a deep, razor-sharp deep zinc and obsidian backdrop highlighted by intentional electric lime and citron accents.

The visual direction combines **minimalist precision** with **subtle glassmorphic depth** and **high-density data architecture**. It prioritizes technical focus, extreme legibility, and rapid contextual scanning for engineering leadership and sprint teams. The aesthetic evokes the precision of an aerospace control cockpit and the fluid efficiency of modern developer tooling: clean boundaries, crisp micro-borders, low-glare dark surfaces, and purposeful semantic risk indicators that isolate blockers instantly.

## Colors

The palette is engineered around high contrast on pure dark surfaces while preventing eye fatigue during prolonged operational cycles.

- **Primary Accent (`#CCFF00` / `#A3E635`):** Electric Lime and Citron serve as active focal anchors—driving primary actions, live progress bars, verified health tags, and key stat metrics without overwhelming content containers.
- **Surface Infrastructure (`#0B0F17`, `#111827`, `#1E293B`):** Multi-tier slate/zinc foundations replace muddy olive tones. `#0B0F17` delivers true canvas depth, `#111827` structures primary card modules, and `#1E293B` provides crisp micro-borders and nested item backgrounds.
- **Semantic Risk & Status Tiers:**
  - *Critical / Blocked:* Crimson (`#EF4444`) with soft ambient tinting (`rgba(239, 68, 68, 0.12)`) for high-urgency callouts and over-allocated capacity.
  - *At Risk / Warning:* Warm Amber (`#F59E0B`) with muted background fills.
  - *Healthy / Verified:* Citron Green (`#A3E635`) for clean, optimistic tracking.
- **Typography & Neutral Tokens:** Primary titles and key metrics utilize Crisp White (`#F8FAFC`), supporting text uses Cool Slate (`#94A3B8`), and subtle metadata uses Dimmed Zinc (`#64748B`).

## Typography

Typography prioritizes quick data parsing through a balance of Plus Jakarta Sans for structural headlines and numeric metric readouts, paired with Inter for dense tabular feeds, side navigation items, and code identifiers.

Numeric counters utilize tabular lining figures (`font-variant-numeric: tabular-nums`) to ensure metrics align evenly across dashboard rows. Category badges and section overhead labels (`label-md`, `label-sm`) are rendered in uppercase with tight tracking for swift section recognition across wide canvases.

## Layout & Spacing

The layout model uses a responsive fluid grid structure with persistent navigation mechanics:
- **Navigation Shell:** Fixed-width 240px collateral left sidebar that collapses to a 64px icon-rail on tablet resolutions.
- **Top Command Bar:** Persistent 64px header featuring global keyboard shortcut search (`Ctrl K`), quick actions, and user profile utilities.
- **Workspace Grid:** 12-column responsive layout within main operational views:
  - *Desktop (1280px+):* 12 columns with 20px (`1.25rem`) gutters and 28px (`1.75rem`) margins. The capacity bar chart spans 7 columns, while project health spans 5 columns.
  - *Tablet (768px - 1279px):* 8 columns with 16px gutters; project health wraps beneath capacity visualizations.
  - *Mobile (< 768px):* Single column stack, sidebar moves to an off-canvas drawer, horizontal scroll enabled for data-dense tables.

## Elevation & Depth

Visual hierarchy is maintained through layered surface luminescence and low-contrast perimeter borders rather than heavy, blurry drop shadows:

- **Level 0 (App Canvas):** Pure obsidian slate (`#0B0F17`).
- **Level 1 (Module Shells & Cards):** Deep zinc fill (`#111827`) paired with a 1px hairline border in `rgba(255, 255, 255, 0.08)`.
- **Level 2 (Active States, Dialogs & Flyouts):** Elevated slate surface (`#1E293B`) with a micro-glow border (`rgba(204, 255, 0, 0.25)` or `rgba(255, 255, 255, 0.12)`) and a diffuse ambient shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.65)`.
- **Glass Accents:** Global search and quick-filter chips incorporate a delicate frosted glass treatment (`backdrop-filter: blur(12px); background: rgba(17, 24, 39, 0.7)`).

## Shapes

The design system employs a disciplined, soft corner radius (Level 1) tailored for enterprise platforms that require dense information architecture:
- Standard buttons, badges, chips, and input elements use `rounded` (4px to 6px) to maintain structured geometry.
- Container cards and modular dashboard panes employ `rounded-lg` (8px to 10px) to delineate content zones cleanly.
- Full circular pills are strictly reserved for high-impact status indicators (e.g., live health badges, count lozenges, and user avatars).

## Components

### Buttons & Action Controls
- **Primary CTA:** Background in Electric Lime (`#CCFF00`), text in Obsidian (`#0B0F17`), weight 600, with a subtle 4px corner radius. On hover: high-brightness lift (`#D8FF33`) with a soft neon aura.
- **Secondary / Ghost:** Transparent background, 1px perimeter line in `rgba(255, 255, 255, 0.14)`, text in `#F8FAFC`. On hover: surface background changes to `rgba(255, 255, 255, 0.05)`.
- **Icon Buttons (Top Bar):** 36x36px bounding box, centered icon, subtle border on hover.

### Badges & Pill Chips
- **Status Badges:** Compact height (20px), text in `10px uppercase`, padding `2px 8px`.
  - *Healthy:* Lime text (`#CCFF00`) with deep jade/lime tinted backdrop (`rgba(163, 230, 53, 0.12)`).
  - *At Risk:* Amber text (`#F59E0B`) with tinted background (`rgba(245, 158, 11, 0.12)`).
  - *Blocked:* Crimson text (`#EF4444`) with high-urgency tinted fill (`rgba(239, 68, 68, 0.15)`).

### Input Fields & Search
- Global search input utilizes a subtle 1px border (`#1E293B`), inset keyboard prompt badge (`Ctrl K`), slate placeholder text (`#64748B`), and shifts to a crisp lime border outline (`#CCFF00`) upon keyboard focus.

### Modular Dashboard Cards
- Encapsulated with a 1px border (`rgba(255, 255, 255, 0.08)`), dark card background (`#111827`), and an upper title bar sporting an uppercase tracker label and quick-link directory chevron.
- Blocked & Overdue items feature a dedicated urgent heading accented with a warning glyph and individual nested rows enclosed in `#151D2E` surfaces.

### Metrics & Workload Allocation
- Numeric stat cards feature a top category label, bold numeric metrics in `metric-display`, and concise secondary text.
- Capacity graphs use rounded vertical bar towers; standard capacity rendered in soft citron (`#A3E635`), while overload (>100%) renders in high-visibility crimson (`#EF4444`).