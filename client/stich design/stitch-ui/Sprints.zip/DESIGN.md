---
name: Delivery Command Center
colors:
  surface: '#0c1321'
  surface-dim: '#0c1321'
  surface-bright: '#323948'
  surface-container-lowest: '#070e1b'
  surface-container-low: '#151c29'
  surface-container: '#19202d'
  surface-container-high: '#232a38'
  surface-container-highest: '#2e3543'
  on-surface: '#dce2f5'
  on-surface-variant: '#c2c6d7'
  inverse-surface: '#dce2f5'
  inverse-on-surface: '#2a303f'
  outline: '#8c90a0'
  outline-variant: '#424655'
  surface-tint: '#b0c6ff'
  primary: '#b0c6ff'
  on-primary: '#002d6e'
  primary-container: '#558dff'
  on-primary-container: '#002661'
  inverse-primary: '#0058ca'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#c0c1ff'
  on-tertiary: '#1000a9'
  tertiary-container: '#8083ff'
  on-tertiary-container: '#0d0096'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00429b'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0c1321'
  on-background: '#dce2f5'
  surface-variant: '#2e3543'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes a high-density, mission-critical workspace tailored for engineering velocity, sprint execution, and backlog orchestration. Built for technical leaders, staff engineers, and delivery managers, the UI communicates uncompromising precision, technical authority, and operational readiness. 

The aesthetic is anchored in an elevated **Technical Glass & Layered Slate Minimalist** style. It moves past noisy, oversaturated cyberpunk tropes into a refined, high-end enterprise cockpit: deep midnight obsidian foundations, structural luminescence, crisp data typography, and restrained ambient glows. Interface elements should evoke the tactile discipline of mission-control telemetry systems while retaining the speed, clean information architecture, and ergonomics expected in next-generation developer tooling.

## Colors

The palette relies on structural darkness to reduce eye fatigue across multi-monitor workstations while using high-frequency chromatic accents strictly for state signaling, hierarchy, and focal tracking.

### Core Architecture
- **Canvas Base (`#050B16` / `#070E1B`):** Deep midnight-obsidian foundation serving as the ultimate canvas sink.
- **Surface Elevation Layers (`#0C182C`, `#101E38`, `#162644`):** Layered cold slate-blue containers that define boards, swimlanes, and floating inspection drawers without heavy contrast shocks.
- **Primary Electric Blue (`#2979FF`):** Active interaction targets, primary actions, selected sprint cycles, and active keyboard navigation cursors.
- **Secondary Cyan / Hyper Teal (`#00E5FF`):** Micro-telemetry indicators, throughput velocity metrics, real-time live web-socket pulses, and automated CI/CD pipeline link status.
- **Tertiary Indigo / Violet (`#6366F1`):** Ambient backdrop radiance, milestone badges, and architectural epic groupings.

### Functional Alerts & Diagnostics
- **Critical & Blocked (`#EF4444` / `#F43F5E`):** Reserved strictly for release blockers, stalled PRs, failed unit runs, and P0 incident badges.
- **At-Risk & Warning (`#F59E0B`):** Scope creeps, sprint spillover warnings, and dependency lag.
- **Nominal Success (`#10B981`):** Verified builds, closed milestones, and merged branch states.

### Text Contrast Tiers
- **Heading Emphatic (`#FFFFFF`):** Absolute white for sprint headers, issue IDs, and key values.
- **Body Cool Neutral (`#E2E8F0`):** Soft high-legibility slate-tinted white for descriptions and work-item titles.
- **Muted Sub-detail (`#94A3B8`):** Low-strain metadata, commit hashes, time stamps, and column counters.

## Typography

The typographic hierarchy bridges modern editorial product styling with dense terminal clarity:
- **Headlines (Plus Jakarta Sans):** Provides structural presence with modern geometric profiles, softened terminals, and tight tracking that preserves compactness on horizontal command boards.
- **Body & Data Copy (Inter):** Employs robust x-height and neutral grotesque balancing for bug descriptions, acceptance criteria, and threaded review comments.
- **Telemetry & Identity (JetBrains Mono):** Dedicated to work-item keys (e.g., `DELV-8942`), git SHAs, sprint burn-rates, and keyboard shortcuts.

Always render `label-caps` in uppercase with letter-spacing expanded to ensure micro-labels (such as lane states or workflow phases) remain instantly legible at small sizes without cluttering visual hierarchy.

## Layout & Spacing

Layouts follow a fluid-first, dense operational canvas optimized for horizontal board scrolling and modular column docking.

- **Canvas Organization:** A master full-bleed canvas anchored by a collapsible 64px icon/navigation rail, a dynamic 48px global sprint header, and horizontal flex-based board columns spanning equal widths (minimum 320px, maximum 420px per column).
- **Responsive Adaptations:**
  - **Desktop / Ultra-wide (>1440px):** Simultaneous multi-column kanban viewing (up to 6 columns visible without horizontal paging), split-pane card inspection drawer pinned to the right edge (480px fixed width).
  - **Laptop / Compact Viewport (1024px - 1439px):** 3-4 visible columns with sticky column headers and gesture-driven horizontal snap scrolling. Drawer overlays content with a structural backdrop-blur.
  - **Mobile / Standup Mode (<1023px):** Single-column tabbed selector interface (`Backlog` | `In Progress` | `Review` | `Done`), cards condensed to high-density summary rows with tap-to-expand capabilities.
- **Internal Density:** Element gutters remain compact (`0.5rem` to `0.875rem`) to ensure maximum visible ticket capacity per viewport screen.

## Elevation & Depth

Visual hierarchy is constructed through structural glassmorphism, cold ambient back-lighting, and precision luminance bounding rather than heavy drop shadows:

1. **Surface 0 (Canvas):** Pure base (`#050B16`). Non-interactive backdrop.
2. **Surface 1 (Lanes & Static Panels):** `#0C182C` with a 1px border rendered via `rgba(255, 255, 255, 0.05)`.
3. **Surface 2 (Interactive Cards & Backlog Rows):** `#101E38` layered with subtle linear gradient descending from `rgba(255, 255, 255, 0.04)` to `rgba(255, 255, 255, 0.00)`. Border is defined with `rgba(56, 189, 248, 0.12)`. Hover states introduce an outer glow: `0 0 16px -4px rgba(41, 121, 255, 0.25)`.
4. **Surface 3 (Flyouts, Active Modals, Context Popovers):** `#162644` with `backdrop-filter: blur(12px)`. Outlined with `rgba(0, 229, 255, 0.22)` along the top edge, casting a multi-layered cast shadow: `0 12px 32px -8px rgba(0, 0, 0, 0.7), 0 0 1px 1px rgba(255, 255, 255, 0.1)`.
5. **State Overlays:** Blocked items cast a muted crimson hazard glow (`rgba(239, 68, 68, 0.15)`); selected cards feature a crisp 1px electric-blue inset outline.

## Shapes

The design system employs a **Soft (`1`)** shape language:
- Standard elements (cards, text fields, menu containers) use **4px (`0.25rem`)** radii.
- Mid-sized framing containers (sprint columns, grouped ticket blocks, slide-in panels) scale to **8px (`0.5rem`)**.
- Status pills, priority tags, and avatar clips adopt compact capsule contours only when encapsulating binary status tags, preventing playful roundness from degrading the serious, technical character of the tool.

## Components

### Action Buttons
- **Primary:** Gradient fill `linear-gradient(135deg, #2979FF 0%, #1E40AF 100%)`, text `#FFFFFF`, subtle 1px border in `rgba(255, 255, 255, 0.2)` with an inner top highlight. Hover triggers a cyan micro-bloom (`box-shadow: 0 0 12px rgba(0, 229, 255, 0.4)`).
- **Secondary / Ghost:** Surface `#0C182C`, text `#E2E8F0`, border `1px solid rgba(255, 255, 255, 0.08)`. Active states illuminate border to `rgba(41, 121, 255, 0.5)`.

### Delivery Work-Item Cards (Kanban / Sprint)
- Rectangular containers on `#101E38` with a 4px radius. Top edge incorporates a faint 1px highlight line. 
- Top row anchors the monospaced issue identifier (e.g., `DELV-1049`) in `#00E5FF` next to the estimation story-point badge.
- Body displays a 2-line clamped title in `#E2E8F0` (`body-md`).
- Footer displays assignee micro-avatar, git branch/PR pill, and color-coded SLA countdown ticker.

### Chips & Metadata Tags
- Height: 20px. Radius: 3px. Padding: 0 6px.
- Monospaced or bold label font.
- Default: `rgba(255, 255, 255, 0.04)` fill with `rgba(255, 255, 255, 0.1)` border and `#94A3B8` text.
- Blocker Chip: `rgba(239, 68, 68, 0.12)` fill, `#EF4444` border, `#FCA5A5` text with pulsating red dot.

### Inputs & Command Bars
- Background: `#070E1B` with inset shadow. Border: `1px solid rgba(255, 255, 255, 0.1)`. 
- Focused State: Border shifts to `#2979FF` accompanied by a localized inner glow (`box-shadow: 0 0 0 1px #2979FF, 0 0 8px rgba(41, 121, 255, 0.3)`).
- Command Palette (Quick Find): Integrated `JetBrains Mono` shortcut indicator (`⌘K`) anchored at the trailing edge.

### Backlog Matrix Rows
- High-density list entries (height: 36px) featuring alternating subtle row striping (`transparent` vs `rgba(255, 255, 255, 0.01)`).
- Draggable re-order grips rendered as twin vertical dotted columns in `#475569`.
- Left-accent border (3px solid) indicating priority status: Red (P0), Amber (P1), Electric Blue (P2), Slate (P3).

### Telemetry Velocity Bars & Burndown Strips
- Track: `#0C182C` with inset 1px depth.
- Fill: Dual stop cyan-to-electric-blue gradient with an ultra-fine trailing edge glow indicating target velocity thresholds.